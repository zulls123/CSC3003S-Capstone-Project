package com.example.foodies


import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.foodies.data.Datasource
import com.example.foodies.ui.theme.FoodiesTheme
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.foodies.model.MenuItemDemoData
import com.example.foodies.model.Vendor

class VendorHomepageActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //TODO: Handle cases where the default values is used
        val vendorName = intent.getIntExtra("stringResourceId", -1)
        val vendorImage = intent.getIntExtra("imageResourceId", -1)
        val vendor = Vendor(vendorName, vendorImage)
        setContent {
            FoodiesTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ){
                    VendorHomepage(vendor)
                }
            }
        }
    }
}

@Composable
fun VendorHomepage(vendor: Vendor, modifier: Modifier = Modifier) {
    //val contextForToast = LocalContext.current.applicationContext
    val context = LocalContext.current
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = modifier
                .fillMaxHeight()
                .fillMaxWidth()
                .padding(10.dp)
        )
        {
            item {
                VendorHomepageCard(vendor, modifier)
                VendorDescriptionCard(modifier)
                Spacer(modifier = Modifier.height(20.dp))
                MenuTitle(modifier)
                MenuItemList(menuItemList = Datasource().loadMenuItems())
            }
        }
        FloatingActionButton(
            modifier = Modifier
                .padding(16.dp)
                .align(alignment = Alignment.BottomEnd),
            elevation = FloatingActionButtonDefaults.elevation(
                defaultElevation = 6.dp,
                pressedElevation = 12.dp,
                hoveredElevation = 8.dp,
                focusedElevation = 8.dp),
            onClick = {
                val myIntent = Intent(context, ReviewActivity::class.java)
                myIntent.putExtra("stringResourceId", vendor.stringResourceId)
                myIntent.putExtra("imageResourceId", vendor.imageResourceId)
                context.startActivity(myIntent)
            }) {
//            text = {Text(text = "Reviews")},
            Icon(imageVector = Icons.Filled.Star, contentDescription = null)

        }
    }

}

@Composable
fun VendorHomepageCard(vendor: Vendor, modifier: Modifier = Modifier){
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(6.dp)
            .clickable { },
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Column( modifier = modifier
        ) {
            Text(
                text = buildAnnotatedString {
                    withStyle(style = SpanStyle(fontWeight = FontWeight.W500)) {
                        append(stringResource(vendor.stringResourceId))
                    }
                },
                fontSize = 25.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            )
            Image(
                painter = painterResource( vendor.imageResourceId),
                contentDescription = null,
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    //.size(200.dp)
                    //.clip(RoundedCornerShape(16.dp))
                    .aspectRatio(16f / 9f)
            )
        }
    }
}

@Composable
fun VendorDescriptionCard(modifier: Modifier = Modifier){
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(6.dp)
            .clickable { },
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Column( modifier = modifier) {
            Row(modifier = Modifier
                .fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween){
                Text(
                    text = buildAnnotatedString {
                        withStyle(style = SpanStyle(fontWeight = FontWeight.W500)) {
                            append("Wait Time:")
                        }
                        append(" 5 mins")
                    },
                    fontSize = 16.sp,
                    //textAlign = TextAlign.Left,
                    modifier = Modifier.padding(6.dp)

                )
                Text(
                    text = buildAnnotatedString {
                        withStyle(style = SpanStyle(fontWeight = FontWeight.W500)) {
                            append("4,1 Stars (3150)")
                        }
                    },
                    fontSize = 16.sp,
                    //textAlign = TextAlign.Right,
                    modifier = Modifier.padding(6.dp))
            }
            Text(
                text = buildAnnotatedString {
                    withStyle(style = SpanStyle(fontWeight = FontWeight.W500)) {
                        append("Location:")
                    }
                    append(" Cissy Gool Plaza")
                },
                fontSize = 16.sp,
                textAlign = TextAlign.Left,
                modifier = Modifier.padding(6.dp))
            Text(
                text = buildAnnotatedString {
                    withStyle(style = SpanStyle(fontWeight = FontWeight.W500)) {
                        append("Operating Hours:")
                    }
                    append(" 08:00 - 16:30")
                },
                fontSize = 16.sp,
                textAlign = TextAlign.Left,
                modifier = Modifier.padding(6.dp))

        }
    }
}

@Composable
fun MenuItemList(menuItemList: List<MenuItemDemoData>, modifier: Modifier = Modifier){
    Column(modifier = modifier.fillMaxWidth()){
        menuItemList.forEach{ item ->
            MenuItemCard(item)
        }
    }
}

@Composable
fun MenuItemCard(menuItem: MenuItemDemoData, modifier: Modifier = Modifier){
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(6.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Row(modifier = modifier) {
            Column(
                modifier = Modifier.weight(1f)
            ){
                Text(
                    text = buildAnnotatedString {
                        withStyle(style = SpanStyle(fontWeight = FontWeight.W500)) {
                            append(stringResource(menuItem.itemName))
                        }
                    },
                    fontSize = 16.sp,
                    modifier = Modifier.padding(6.dp))
            }
            Column(
                modifier = Modifier.weight(0.5f)
            ){
                Text(
                    text = buildAnnotatedString {
                        append(stringResource(menuItem.price))
                    },
                    fontSize = 16.sp,
                    modifier = Modifier.padding(6.dp))
            }
            Column(
                modifier = Modifier.weight(0.5f)
            ){
                Text(
                    text = buildAnnotatedString {
                        append(stringResource(menuItem.inStock))
                    },
                    fontSize = 16.sp,
                    modifier = Modifier.padding(6.dp))
            }
        }
    }
}

@Composable
fun MenuTitle(modifier: Modifier = Modifier){
    Column(modifier = modifier) {
        Text(
            text = buildAnnotatedString {
                withStyle(style = SpanStyle(fontWeight = FontWeight.W500)) {
                    append("Menu")
                }
            },
            fontSize = 25.sp,
            modifier = Modifier.padding(6.dp)
        )
        Row(modifier = Modifier) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = buildAnnotatedString {
                        withStyle(style = SpanStyle(fontWeight = FontWeight.W500)) {
                            append("Item")
                        }
                    },
                    fontSize = 16.sp,
                    modifier = Modifier.padding(6.dp)
                )
            }
            Column(
                modifier = Modifier.weight(0.5f)
            ) {
                Text(
                    text = buildAnnotatedString {
                        append("Price")
                    },
                    fontSize = 16.sp,
                    modifier = Modifier.padding(6.dp)
                )
            }
            Column(
                modifier = Modifier.weight(0.5f)
            ) {
                Text(
                    text = buildAnnotatedString {
                        append("In Stock")
                    },
                    fontSize = 16.sp,
                    modifier = Modifier.padding(6.dp)
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    FoodiesTheme {
    }
}