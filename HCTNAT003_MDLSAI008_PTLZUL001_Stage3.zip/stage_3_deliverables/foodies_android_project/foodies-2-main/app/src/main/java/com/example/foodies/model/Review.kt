package com.example.foodies.model

import java.sql.RowId


data class Review(
    var reviewerNameId: String,
    var starAverageId: Double,
    var reviewContentId: String,
    var reviewDate: String)
{
    fun getReviewerNameIds(): String {
        return reviewerNameId
    }
    fun setReviewerNameIds(updatedReviewerNameIds:String) {
        reviewerNameId = updatedReviewerNameIds
    }

    fun getStarAverageIds(): Double {
        return starAverageId
    }
    fun setStarAverageIds(updatedStarAverageId: Double) {
        starAverageId = updatedStarAverageId
    }

    fun getReviewContentIds(): String {
        return reviewContentId
    }
    fun setReviewContentIds(updatedReviewContentId: String) {
        reviewContentId = updatedReviewContentId
    }
    fun getReviewDates(): String {
        return reviewDate
    }
    fun setReviewDates(updatedReviewDates: String) {
        reviewDate = updatedReviewDates
    }






}


