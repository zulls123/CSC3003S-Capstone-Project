package com.example.foodies.model
data class Student(val fName: String,
                   val sName: String,
                   var mail: String,
                   var pass: String,
                   val studentNumber: String) : Person(firstName = fName, lastName = sName, email = mail, password = pass) {
    override fun getID(): String {
        return studentNumber
    }
}


