package com.example.foodies.model
abstract class Person(val firstName: String,
                      val lastName: String,
                      var email: String,
                      var password: String) {
    fun getName(): String {
        return firstName
    }
    fun getSurname(): String {
        return lastName
    }
    fun getEmailAddress(): String {
        return email
    }
    fun setEmailAddress(updatedEmail: String) {
        email = updatedEmail
    }
    fun getPasswd(): String {
        return password
    }
    fun setPasswd(updatedPassword: String) {
        password = updatedPassword
    }
    abstract fun getID(): String
}

