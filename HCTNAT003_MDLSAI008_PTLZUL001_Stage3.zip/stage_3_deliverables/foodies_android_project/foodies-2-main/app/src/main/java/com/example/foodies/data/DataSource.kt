package com.example.foodies.data

import com.example.foodies.model.Vendor
import com.example.foodies.R
import com.example.foodies.model.MenuItemDemoData
import com.example.foodies.model.ReviewDemoData

//
class Datasource() {
    fun loadVendors(): List<Vendor> {
        return listOf<Vendor>(
            Vendor(R.string.vendor1, R.drawable.ic_launcher_background),
            Vendor(R.string.vendor2, R.drawable.ic_launcher_background),
            Vendor(R.string.vendor3, R.drawable.ic_launcher_background),
            Vendor(R.string.vendor4, R.drawable.ic_launcher_background),
            Vendor(R.string.vendor5, R.drawable.ic_launcher_background),
            Vendor(R.string.vendor6, R.drawable.ic_launcher_background),
            Vendor(R.string.vendor7, R.drawable.ic_launcher_background))
    }
    fun loadMenuItems(): List<MenuItemDemoData> {
        return listOf<MenuItemDemoData>(
            MenuItemDemoData(R.string.menu_item1, R.string.menu_item_price1, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item2, R.string.menu_item_price2, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item3, R.string.menu_item_price3, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item4, R.string.menu_item_price4, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item5, R.string.menu_item_price5, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item6, R.string.menu_item_price6, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item7, R.string.menu_item_price7, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item8, R.string.menu_item_price8, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item9, R.string.menu_item_price9, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item10, R.string.menu_item_price10, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item11, R.string.menu_item_price11, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item12, R.string.menu_item_price12, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item13, R.string.menu_item_price13, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item14, R.string.menu_item_price14, R.string.in_stock ),
            MenuItemDemoData(R.string.menu_item15, R.string.menu_item_price15, R.string.in_stock )
        )
    }

    fun loadReviewItems(): List<ReviewDemoData>{
        return listOf(
            ReviewDemoData( R.string.username1, R.string.star_rating1, R.string.review1, R.string.review_date1),
            ReviewDemoData( R.string.username2, R.string.star_rating2, R.string.review2, R.string.review_date2),
            ReviewDemoData( R.string.username3, R.string.star_rating3, R.string.review3, R.string.review_date3),
            ReviewDemoData( R.string.username4, R.string.star_rating4, R.string.review4, R.string.review_date4),
            ReviewDemoData( R.string.username5, R.string.star_rating5, R.string.review5, R.string.review_date5),
            ReviewDemoData( R.string.username6, R.string.star_rating6, R.string.review6, R.string.review_date6),
            ReviewDemoData( R.string.username7, R.string.star_rating7, R.string.review7, R.string.review_date7),
            ReviewDemoData( R.string.username8, R.string.star_rating8, R.string.review8, R.string.review_date8),
            ReviewDemoData( R.string.username9, R.string.star_rating9, R.string.review9, R.string.review_date9),
            ReviewDemoData( R.string.username10, R.string.star_rating10, R.string.review10, R.string.review_date10),
            ReviewDemoData( R.string.username11, R.string.star_rating11, R.string.review11, R.string.review_date11),
            ReviewDemoData( R.string.username12, R.string.star_rating12, R.string.review12, R.string.review_date12),
            ReviewDemoData( R.string.username13, R.string.star_rating13, R.string.review13, R.string.review_date13),
            ReviewDemoData( R.string.username14, R.string.star_rating14, R.string.review14, R.string.review_date14),
            ReviewDemoData( R.string.username15, R.string.star_rating15, R.string.review15, R.string.review_date15)

            )
    }
}