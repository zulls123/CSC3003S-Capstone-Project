package com.example.foodies.model
data class Staff(val fName: String,
                 val sName: String,
                 var mail: String,
                 var pass: String,
                 val staffNumber: String) : Person(firstName = fName, lastName = sName, email = mail, password = pass) {
    override fun getID(): String {
        return staffNumber
    }
}

