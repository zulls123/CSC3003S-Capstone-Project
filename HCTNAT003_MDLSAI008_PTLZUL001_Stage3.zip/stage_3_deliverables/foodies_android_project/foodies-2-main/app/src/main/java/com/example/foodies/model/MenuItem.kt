package com.example.foodies.model

import androidx.annotation.StringRes

 data class MenuItem(
    var itemName: String,
    var price: String,
    var inStock: Boolean
) {

     //getters
     fun getItemNames(): String {
         return itemName
     }

     fun getPrices(): String {
         return price
     }

     fun getStocks(): Boolean {
         return inStock
     }

     //setters
     fun setItemNames(updatedItemName:String){
         itemName = updatedItemName
     }

     fun setPrices(updatedPrice:String){
          price = updatedPrice
     }

     fun setStocks(updatedStock:Boolean) {
         inStock = updatedStock
     }




 }