package com.example.foodies.model

import androidx.annotation.StringRes

data class ReviewDemoData(
    @StringRes val reviewerNameId: Int,
    @StringRes val starAverageId: Int,
    @StringRes val reviewContentId: Int,
    @StringRes val reviewDate: Int)