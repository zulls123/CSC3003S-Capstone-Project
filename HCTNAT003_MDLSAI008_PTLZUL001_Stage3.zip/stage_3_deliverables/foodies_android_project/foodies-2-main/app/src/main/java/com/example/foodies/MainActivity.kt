package com.example.foodies

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.foodies.data.Datasource
import com.example.foodies.model.Vendor
import com.example.foodies.ui.theme.FoodiesTheme

class MainActivity : ComponentActivity() { //
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FoodiesTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VendorsApp()
                }
            }
        }
    }
}

@Composable
fun VendorCard(vendor: Vendor, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Card(modifier = modifier.clickable{
        val myIntent = Intent(context, VendorHomepageActivity::class.java)
        myIntent.putExtra("stringResourceId", vendor.stringResourceId)
        myIntent.putExtra("imageResourceId", vendor.imageResourceId)
        context.startActivity(myIntent)
    }) {
        Column{
            Image(
                painter = painterResource(vendor.imageResourceId),
                contentDescription = stringResource(vendor.stringResourceId),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(194.dp),
                contentScale = ContentScale.Crop
            )
            Text(
                text = LocalContext.current.getString(vendor.stringResourceId),
                modifier = Modifier.padding(16.dp),
                style = MaterialTheme.typography.headlineSmall
            )
        }
    }
}

@Composable
fun VendorList(vendorList: List<Vendor>, modifier: Modifier = Modifier) {
    LazyColumn(modifier = modifier) {
        items(vendorList) { vendor ->
            VendorCard(
                vendor = vendor,
                modifier = Modifier.padding(8.dp)
            )

        }
    }

}

@Composable
fun VendorsApp() {
    VendorList(
        vendorList = Datasource().loadVendors(),
    )
}

@Preview
@Composable
private fun VendorCardPreview() {
    VendorCard(Vendor(R.string.vendor1, R.drawable.ic_launcher_background))
}