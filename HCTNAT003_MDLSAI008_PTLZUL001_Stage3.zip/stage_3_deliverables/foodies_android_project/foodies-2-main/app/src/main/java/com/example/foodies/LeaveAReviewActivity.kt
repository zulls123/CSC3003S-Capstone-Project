package com.example.foodies



import android.app.Activity
import android.content.Context
import android.graphics.drawable.LayerDrawable
import android.media.Rating
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RatingBar
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.compose.ui.platform.LocalContext

//make appcombatactivity if run into issues with componentactivity
class LeaveAReviewActivity : ComponentActivity() {
    //object for rating bar


    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leave_a_review)

        //add text views
        val cleanlinessTextView = findViewById<TextView>(R.id.cleanliness_text)
        val orderTimeTextView = findViewById<TextView>(R.id.order_time_text)
        val serviceTextView = findViewById<TextView>(R.id.service_text)



        //add rating bar object
        val cleanlinessRate = findViewById<RatingBar>(R.id.cleanlinessRate)
        val orderTimeRate = findViewById<RatingBar>(R.id.orderTimeRate)
        val serviceRate = findViewById<RatingBar>(R.id.serviceRate)

        //rating view
        val submitButton = findViewById<Button>(R.id.submitButton)
        val cancelButton = findViewById<Button>(R.id.cancelButton)



        //code for user to input text and store text
        val editText = findViewById<EditText>(R.id.editText)
        val userText = editText.text.toString()

        //to store userText persistently even after app closed and reopened
        val sharedPrefs = getSharedPreferences("myPreferences", Context.MODE_PRIVATE)
        val editor = sharedPrefs.edit()
        editor.putString("userTextKey", userText)
        editor.apply()
        val userTextStored = sharedPrefs.getString("userText","")


        //set a listener to react to changes in rating bar
        val sharedPreferences = getSharedPreferences("ratings_prefs", Context.MODE_PRIVATE)


        //store ratings
        cleanlinessRate.setOnRatingBarChangeListener { _, rating, _ ->
            val editor = sharedPreferences.edit()
            editor.putFloat("cleanliness_rating", rating)
            editor.apply()
        }

        orderTimeRate.setOnRatingBarChangeListener { _, rating, _ ->
            val editor = sharedPreferences.edit()
            editor.putFloat("order_time_rating", rating)
            editor.apply()
        }

        serviceRate.setOnRatingBarChangeListener { _, rating, _ ->
            val editor = sharedPreferences.edit()
            editor.putFloat("service_rating", rating)
            editor.apply()
        }

        val cleanlinessRating = sharedPreferences.getFloat("cleanliness_rating", 0.0f)
        val orderTimeRating = sharedPreferences.getFloat("order_time_rating", 0.0f)
        val serviceRating = sharedPreferences.getFloat("service_rating", 0.0f)

    }

    //code for rating bar





}

