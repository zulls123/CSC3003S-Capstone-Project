package com.example.foodies.model

import androidx.annotation.StringRes

data class MenuItemDemoData(
    @StringRes val itemName: Int,
    @StringRes val price: Int,
    @StringRes val inStock: Int
)