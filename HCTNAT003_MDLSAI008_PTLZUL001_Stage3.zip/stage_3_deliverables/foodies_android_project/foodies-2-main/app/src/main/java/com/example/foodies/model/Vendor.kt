package com.example.foodies.model

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

/*data class Vendor(val fName: String,
                  val sName: String,
                  var mail: String,
                  var pass: String,
                  val vendorNumber: String,
                  @StringRes val stringResourceId: Int,
                  @DrawableRes val imageResourceId: Int)
    : Person(firstName = fName, lastName = sName, email = mail, password = pass) {

    override fun getID(): String {
        return vendorNumber
    }
}*/

data class Vendor(
    @StringRes val stringResourceId: Int,
    @DrawableRes val imageResourceId: Int
)
